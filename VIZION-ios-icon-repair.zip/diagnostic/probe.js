async function check(){
  const el=document.getElementById("isolation");
  try{
    if(!isSecureContext)throw Error("Use a dedicated HTTPS preview for representative iPhone installation. HTTP here is for local inspection only.");
    if(location.hostname==="vizion-io.vercel.app")throw Error("Production origin is forbidden for this diagnostic.");
    if("serviceWorker" in navigator){
      const registrations=await navigator.serviceWorker.getRegistrations();
      if(navigator.serviceWorker.controller||registrations.length)throw Error("Existing service worker detected. Use an unused origin. Nothing has been removed.");
    }
    for(const p of ["/apple-touch-icon.png","/apple-touch-icon-precomposed.png","/apple-touch-icon-180x180.png","/favicon.ico","/manifest.webmanifest","/sw.js"]){
      const r=await fetch(p,{cache:"no-store",credentials:"include",redirect:"error"});
      if(r.status!==404)throw Error("Unexpected root fallback or interception: "+p+" returned "+r.status);
    }
    const res=await fetch("/build.json",{cache:"no-store",credentials:"include",redirect:"error"});
    if(!res.ok||!res.headers.get("content-type")?.includes("json"))throw Error("Build metadata was intercepted.");
    const b=await res.json();
    for(const c of b.cases){
      const manifestResponse=await fetch("/"+c.key+"/manifest.webmanifest",{cache:"no-store",credentials:"include",redirect:"error"});
      if(!manifestResponse.ok||!manifestResponse.headers.get("content-type")?.includes("manifest+json"))throw Error("Manifest was intercepted: "+c.key);
      const manifest=await manifestResponse.json();
      if(manifest.id!=="/vizion-icon-test/"+b.version+"/"+c.key||manifest.icons.length!==1||manifest.icons[0].src!==c.icon)throw Error("Unexpected manifest identity or icon: "+c.key);
      for(const p of new Set([c.icon,c.apple].filter(Boolean))){
        const r=await fetch(p,{cache:"no-store",credentials:"include",redirect:"error"});
        const expected=b.files[p];
        if(!r.ok||!r.headers.get("content-type")?.startsWith(expected.type.split(";")[0]))throw Error("Wrong asset response: "+p);
        const bytes=await r.arrayBuffer();
        const hash=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",bytes)),x=>x.toString(16).padStart(2,"0")).join("");
        if(hash!==expected.sha256)throw Error("Asset hash mismatch: "+p);
      }
    }
    el.textContent="Isolation and asset preflight passed in this browser. This is not Home Screen acceptance. Record the origin, version and appearance for each installation.";
    el.dataset.result="passed";
  }catch(error){el.textContent="Do not interpret installation results yet: "+error.message;el.dataset.result="blocked";}
}check();