# VIZION iOS icon repair: implementation and verification report

Repository: SeanVasey/VIZION
Reference main: 04602b3dc69def9e5109202458a52e921e16a387
Delivery: reviewable patch and isolated static diagnostic, not a pushed branch or PR.
Status: targeted asset and browser-rendering checks verified; full repository gate
and physical iOS Home Screen acceptance pending.

## What was implemented

The patch changes 15 paths. It keeps the canonical logo, existing mark gradient,
stroke width, position, brand tokens and full-bleed lime Apple PNG. It does not
ship a permanently dark Apple icon or remove the Apple link to force SVG.

1. `scripts/generate-icons.mjs`: adds token-derived presentation `fill` to the
   scalable SVG's plate, retaining the class-based dark override. Corrects the
   reversed CSS-specificity claim and unverified source-selection guarantees.
2. `public/icons/app-icon.svg`: regenerated output from that generator. The only
   artwork change is the plate's fallback attribute. Glyph paths are unchanged.
3. `src/app/layout.tsx`: corrects source-selection and old artwork comments;
   runtime metadata stays unchanged. One explicit outlined Apple PNG remains.
4. `next.config.ts`: adds two exact, later cache exceptions for the mutable
   Apple PNG and adaptive SVG: `public, max-age=0, must-revalidate`. Other asset
   trees, security headers and service-worker configuration remain unchanged.
5. `tests/unit/app-icon-svg.test.ts`: replaces the incorrect no-fill assertion
   with a token-derived, CSS-overridable presentation-fallback assertion.
6. `scripts/verify-icon-repair.mjs` and its new Vitest wrapper: checks canonical
   geometry, alpha, dimensions, pixel fallback, Android safe area, manifest
   references and isolated diagnostic generation/HTTP responses.
7. `scripts/check-icon-browser.mjs` and its new Playwright wrapper: checks actual
   light/dark SVG pixels at 60, 120 and 180 px, stable opaque foreground pixels,
   and a stylesheet-stripped fallback with a missing-attribute negative control.
8. `tests/e2e/icon-install-inputs.spec.ts`: adds real Next-server checks for
   server-rendered/hydrated links, identity, response MIME/hash/dimensions and
   cache exceptions. This wrapper still needs the full app test environment.
9. `scripts/icon-diagnostic.mjs`: builds an isolated static A/B/C installation
   diagnostic outside the repository, with versioned asset hashes and separate
   test identities. It refuses repository output and existing destinations.
10. `docs/runbooks/icon-install-repair.md`: records the current contract,
    verification and physical-device procedure. Three additional patch hunks
    insert scope corrections into ADR-0015, ADR-0017 and the iOS runbook while
    retaining their historical text.

The patch does not change package.json, the lockfile, production manifest id,
start_url or scope, authentication, CSP, in-app themes, data, or SW behavior.
No remote write, deployment, merge, force push or storage deletion occurred.

## Cause and evidence

The original generator and unit test mistakenly treated a presentation fill as
stronger than a CSS class. The SVG now has a deterministic lime fallback, and
actual Chromium pixels verify that the dark class still overrides it. This is
hardening of an identified defect, not proof that iOS ignores SVG styles.

The layout described the explicit Apple PNG as a fallback subordinate to a
manifest SVG. That conflicts with WebKit's documented explicit Apple-touch
precedence. The patch corrects the contract without an unverified production
source switch. The A/B/C probes distinguish source selection from system
restyling and from actual SVG CSS branch changes.

Authorized live Vercel reads showed the expected one-Apple/one-manifest head,
valid manifest JSON, SVG and PNG responses, and a 24-hour fresh plus seven-day
stale-while-revalidate cache on the fixed installation asset URLs. The new
exact cache exceptions address future HTTP response revalidation. They do not
invalidate previously fresh cached responses or replace already captured iOS
icons. The repair has not been deployed.

The binary Vercel response was converted to lossy text by the connector. Its
PNG ETag matches the independently computed local MD5, but this is only
corroboration, not a raw remote-byte SHA-256 verification. The full redirect
chain, anonymous credential behavior and every deployed candidate were not
verified. The observed deployment was not mapped conclusively to Git HEAD.
`evidence/live-install-inputs.json` records these boundaries without access tokens.

## Executed checks

| Check | Result and scope |
| --- | --- |
| Original edited-file retrieval | Five complete originals verified against their Git blob SHAs before editing. |
| Canonical geometry | Both output paths match the master exactly; transform, fill rule and stroke-under-fill order retained. |
| Asset verifier | All 9 groups passed, including 13 transparent exports, 2 maskable sizes, Apple PNG pixels and diagnostic local HTTP checks. |
| Real Chromium rendering | All 9 cases passed: 3 light/dark comparisons and 6 fallback cases. At 60/120/180 px, 135/1670/4803 eroded interior pixels respectively remain exactly invariant. |
| Diagnostic CSS marker rendering | Both branches passed: light lower-left square, dark lower-right circle. This is browser rendering only. |
| Source syntax | 11 checks passed using Node/V8 and the available TypeScript parser. Not semantic typechecking or lint. |
| Generation | `npm run generate:icons` executed repeatedly. Final two runs produced identical hashes for all 31 outputs. |
| Local before/after comparison | Only app-icon.svg changes between the unmodified generator and repaired generator under the same local renderer. |
| Reference byte reproduction | 26 of 31 original outputs match reference Git blobs, including Apple PNG and both maskable outputs. Five small exports differ even with the unmodified generator; see below. |
| Patch application | Apply-check, application, and reverse-check passed against the five complete source baselines, seven new files and three fetched document-header contexts. |
| Whitespace | `git diff --check` passed. This is not Prettier verification. |
| Browser HTTP navigation to harness | Blocked by administrator policy before page load. No browser policy bypass attempted. Node HTTP checks and in-memory SVG rendering were verified separately. |

The local image renderer is Sharp 0.34.1, not the repository's requested
Sharp 0.35.3 toolchain. Before modification, favicon-16.png, favicon-32.png,
favicon-48.png, favicon.ico and icon-48.png did not reproduce the reference
byte hashes. The cause of those existing renderer/output differences was not
established. None of these five regenerated files is included in the patch.
Do not overwrite them from a locally regenerated matrix. Run the generation
check with the actual lockfile in the complete checkout before merging.

The distributed asset examples include only the repaired SVG and unchanged,
reference-matching Apple PNG. The static diagnostic carries its own explicitly
marked test-only derivatives. It is not a substitute production asset pack.

## Full application gate: attempted, not passed

This was a reconstructed source workspace, not a complete clone. The runtime
could not resolve GitHub or the npm registry. The GitHub connector allowed
reading but not pushing. Original source was retrieved through the connector,
with exact blob checks for edited complete files. No dependencies were upgraded.

| Command | Actual outcome |
| --- | --- |
| `npm run lint` | Exit 127: Next executable absent. |
| `npm run typecheck` | Exit 1: partial checkout has no complete TS project; global tsc printed usage. |
| `npm run test` | Exit 127: Vitest absent. The shared standalone asset verifier ran separately and passed. |
| `npm run test:e2e` | Exit 1: available Playwright driver lacks the repo test runner's `test` command. Shared browser helpers ran separately in Chromium 144.0.7559.96. |
| `npm run build` | Exit 1 at prebuild because the reconstruction does not contain the full build tree. |
| `npm run format:check` | Exit 127: Prettier absent. New files still need the repo formatting pass. |

These are environment-blocked gates, not green CI and not evidence of a failed
full build of the actual repository. Exact command logs are included. The
Playwright wrappers, actual repaired Next response headers, WebKit leg and
whole-app regressions remain unverified until the complete environment runs.

## Apply without overwriting unrelated work

Use a complete current checkout. Inspect current HEAD and working changes;
keep them intact. The patch was made against the reference commit, not an
instruction to reset to it. A context failure requires review against newer
changes, not force application. Do not merge or deploy automatically.

```sh
git status --short
git rev-parse HEAD
git switch -c fix/ios-icon-source-repair
# Replace the path with the extracted patch location.
git apply --check /path/to/VIZION-ios-icon-repair.patch
git apply /path/to/VIZION-ios-icon-repair.patch
npm ci
npm run generate:icons
node scripts/verify-icon-repair.mjs
npm run lint
npm run typecheck
npm run test
npm run test:e2e
npm run build
npm run format:check
```

Use the installed repository Prettier on changed text files if its check
requires formatting, then rerun the gate. Do not do a whole-repo reformat or
upgrade dependencies. The ZIP contains source copies for review, but the
patch is the authoritative application method. Historical documents are
changed by context hunks; no truncated document copies are supplied.

## Diagnostic access

No live preview URL is claimed. The ready-built `diagnostic/` directory in the
ZIP must be served as the root of a dedicated, unused HTTPS origin for iPhone
installation. Its index lists the three cases, base SHA, actual working-tree
version and asset hashes. Preserve any required preview authentication; the
preflight rejects redirects, invalid manifest JSON, hash mismatches, existing
workers and implicit root-icon fallbacks. Do not copy it into production.

After applying the patch and installing dependencies, inspect the provided
bundle locally:

```sh
node scripts/icon-diagnostic.mjs serve /path/to/extracted/diagnostic
# Local inspection only: http://127.0.0.1:4173/
```

To rebuild from the checkout, choose a NEW directory outside it:

```sh
node scripts/icon-diagnostic.mjs build ../vizion-icon-probe-NEW
```

For an existing authorized static-preview workflow, publish only the generated
directory as its own root, with no application build command, no production
metadata/SW, no catch-all rewrite and no implicit root icons. The included
standalone vercel.json applies to that diagnostic only. It does not alter the
production project's configuration. Record the actual HTTPS URL after deployment.

A offers the unchanged outlined Apple PNG. B offers only an adaptive manifest
SVG; a square/circle at different positions distinguishes CSS branches from
mere OS darkening. C offers differently marked PNG and SVG sources to identify
which one was selected. The canonical mark is not edited for these markers.

## Remaining physical-device acceptance

Use the separate diagnostics first, leaving production and local data alone.
For A, B and C, install under Light and observe Light and Dark; then perform a
separate Dark installation and observe Dark and Light. Record exact iOS build,
Home Screen customization setting, immediate/later observations, test version
and screenshots. Test Auto separately. Clear/Tinted are separate results, not
ordinary Dark acceptance. Check marker positions as well as background color.

Before removing any production installation, confirm export/sync of local-only
data. Do not clear all Safari website data. A pass requires lime in normal
Light, a readable lime-filled outlined symbol on the observed dark plate and
no incorrectly frozen background or geometry damage. No such device pass has
been performed here.
